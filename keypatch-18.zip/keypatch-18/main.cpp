#include "keypatch_core.h"
#include "test_fixtures.h"
#include <commctrl.h>
#include <shobjidl.h>
#include <shellapi.h>
#include <memory>
#include <thread>

namespace {
constexpr int PathBox=101, Browse=102, Check=103, Patch=104, Restore=105;
constexpr int Serial=106, Generate=107, CopySerial=108, Name=109, Organization=110;
constexpr int Request=111, PasteRequest=112, Inspect=113, Calculate=114, Response=115, CopyResponse=116;
constexpr UINT JobComplete = WM_APP+1;
constexpr wchar_t ClassName[] = L"NavicatKeypatch18NativeCpp";
using keypatch::fs::path;

std::wstring ReadText(HWND window) {
    const int length = GetWindowTextLengthW(window);
    std::wstring text(static_cast<std::size_t>(length)+1, L'\0');
    text.resize(GetWindowTextW(window, text.data(), length+1));
    return text;
}
path ExecutablePath() {
    std::wstring buffer(32768, L'\0');
    const auto length = GetModuleFileNameW(nullptr, buffer.data(), static_cast<DWORD>(buffer.size()));
    if (!length || length == buffer.size()) keypatch::Fail("无法取得程序路径。");
    buffer.resize(length); return path(buffer);
}
path DefaultDirectory() {
    auto parent = ExecutablePath().parent_path();
    while (!parent.empty()) {
        if (keypatch::fs::is_regular_file(parent/L"navicat.exe") && keypatch::fs::is_regular_file(parent/L"libcc.dll")) return parent;
        const auto next = parent.parent_path(); if (next == parent) break; parent = next;
    }
    return keypatch::fs::current_path();
}
struct JobResult { keypatch::State state = keypatch::State::Unknown; std::wstring message, error; };
struct App {
    HWND window = nullptr;
    std::map<int, HWND> controls;
    HFONT normal=nullptr, heading=nullptr, code=nullptr, serialFont=nullptr;
    HBRUSH background=nullptr;
    int dpi=96, errorCount=0;
    bool ready=false, busy=false, testing=false;
    keypatch::State state=keypatch::State::Unknown;
    std::thread worker;
    ~App() {
        if (worker.joinable()) worker.join();
        for (auto resource : {normal, heading, code, serialFont}) if (resource) DeleteObject(resource);
        if (background) DeleteObject(background);
    }
    int Scale(int n) const { return MulDiv(n, dpi, 96); }
    HWND Get(int id) const { return controls.at(id); }
    std::wstring Text(int id) const { return ReadText(Get(id)); }
    void Set(int id, const std::wstring& text) {
        SetWindowTextW(Get(id), text.c_str());
        if (!ready) return;
        if (id==Serial || id==Name || id==Organization || id==Request) ClearResponse();
        else if (id==PathBox) DirectoryChanged();
    }
    void Status(const std::wstring& text) { Set(210, text); }
    void Error(const std::wstring& text) {
        ++errorCount; Status(text);
        if (!testing) MessageBoxW(window, text.c_str(), L"操作未完成", MB_OK|MB_ICONERROR);
    }
    void ClearResponse() {
        if (!Text(Response).empty()) {
            Set(Response, L""); Status(L"输入已变化，请重新计算激活码。"); SyncButtons();
        }
    }
    void DirectoryChanged() {
        state=keypatch::State::Unknown; Set(204, L"目录已变化，请重新检查版本。"); SyncButtons();
    }
    void SyncButtons() {
        for (int id : {Browse, Check, Patch, Restore, Generate, CopySerial, PasteRequest, Inspect, Calculate, CopyResponse})
            EnableWindow(Get(id), !busy);
        EnableWindow(Get(PathBox), !busy);
        if (!busy) {
            EnableWindow(Get(Patch), state==keypatch::State::Original);
            EnableWindow(Get(Restore), state==keypatch::State::Patched);
            EnableWindow(Get(CopyResponse), !Text(Response).empty());
        }
    }
    HWND Control(int id, const wchar_t* kind, const wchar_t* text, DWORD style=0, HFONT font=nullptr) {
        const bool edit = wcscmp(kind, L"EDIT")==0;
        auto child=CreateWindowExW(edit ? WS_EX_CLIENTEDGE : 0, kind, text, WS_CHILD|WS_VISIBLE|style,
            0,0,10,10,window,reinterpret_cast<HMENU>(static_cast<INT_PTR>(id)),GetModuleHandleW(nullptr),nullptr);
        keypatch::WinCheck(child!=nullptr, "无法创建窗口控件");
        SendMessageW(child, WM_SETFONT, reinterpret_cast<WPARAM>(font ? font : normal), TRUE);
        if (edit) SendMessageW(child, EM_SETLIMITTEXT, 16384, 0);
        controls.emplace(id, child); return child;
    }
    void Button(int id, const wchar_t* text) { Control(id,L"BUTTON",text,WS_TABSTOP|BS_PUSHBUTTON); }
    void CreateControls() {
        HDC dc=GetDC(window); dpi=GetDeviceCaps(dc, LOGPIXELSY); ReleaseDC(window,dc);
        auto font=[&](const wchar_t* face,int size,int weight=FW_NORMAL) {
            return CreateFontW(-Scale(size),0,0,0,weight,FALSE,FALSE,FALSE,DEFAULT_CHARSET,
                OUT_DEFAULT_PRECIS,CLIP_DEFAULT_PRECIS,CLEARTYPE_QUALITY,DEFAULT_PITCH,face);
        };
        normal=font(L"Microsoft YaHei UI",16); heading=font(L"Microsoft YaHei UI",28,FW_BOLD);
        code=font(L"Consolas",17); serialFont=font(L"Consolas",21);
        background=CreateSolidBrush(RGB(246,248,251));
        auto label=[&](int id,const wchar_t* text,HFONT f=nullptr) { Control(id,L"STATIC",text,0,f); };
        label(201,L"Navicat Keypatch",heading);
        label(202,L"Premium 18.0.6 · Windows x64 · C++ 原生程序");
        label(203,L"1  安装目录");
        Control(PathBox,L"EDIT",DefaultDirectory().c_str(),WS_TABSTOP|ES_AUTOHSCROLL);
        Button(Browse,L"选择目录"); label(204,L"选择安装目录后检查版本。");
        Button(Check,L"检查版本"); Button(Patch,L"应用补丁并备份"); Button(Restore,L"恢复原版");
        label(205,L"2  序列号与注册信息");
        Control(Serial,L"EDIT",serial::Format(serial::Generate()).c_str(),WS_TABSTOP|ES_AUTOHSCROLL,serialFont);
        Button(Generate,L"生成序列号"); Button(CopySerial,L"复制序列号");
        label(206,L"注册姓名"); Control(Name,L"EDIT",L"User",WS_TABSTOP|ES_AUTOHSCROLL);
        label(207,L"注册组织"); Control(Organization,L"EDIT",L"Personal",WS_TABSTOP|ES_AUTOHSCROLL);
        label(208,L"3  请求码（应用补丁并重启后，从 Navicat 复制）");
        const DWORD multi=WS_TABSTOP|ES_MULTILINE|ES_AUTOVSCROLL|WS_VSCROLL|ES_WANTRETURN;
        Control(Request,L"EDIT",L"",multi,code); Button(PasteRequest,L"粘贴请求码");
        Button(Inspect,L"检查请求"); Button(Calculate,L"计算激活码");
        label(209,L"4  激活码（复制回 Navicat 手动激活窗口）");
        Control(Response,L"EDIT",L"",multi|ES_READONLY,code); Button(CopyResponse,L"复制激活码");
        label(210,L"先应用补丁，再使用重新生成的请求码。");
        ready=true; Layout(); SyncButtons();
    }
    void Layout() {
        if (!ready) return;
        RECT r{}; GetClientRect(window,&r);
        const int width=MulDiv(r.right,96,dpi),height=MulDiv(r.bottom,96,dpi),margin=26,available=width-52;
        auto place=[&](int id,int x,int y,int w,int h) { MoveWindow(Get(id),Scale(x),Scale(y),Scale(w),Scale(h),TRUE); };
        auto row=[&](int id,int y,int h) { place(id,margin,y,available,h); };
        row(201,15,36); row(202,53,25); row(203,88,24);
        place(PathBox,margin,116,available-110,31); place(Browse,width-margin-100,116,100,31);
        row(204,154,25); place(Check,margin,184,110,33); place(Patch,margin+120,184,172,33); place(Restore,margin+302,184,110,33);
        row(205,236,24); place(Serial,margin,265,available-302,37);
        place(Generate,width-margin-292,265,140,37); place(CopySerial,width-margin-142,265,142,37);
        place(206,margin,317,76,28); const int first=(available-186)/2;
        place(Name,margin+80,313,first,31); place(207,margin+first+100,317,76,28);
        place(Organization,margin+first+180,313,available-first-180,31);
        row(208,363,25);
        const int requestHeight=std::max(65,105+(height-800)/2);
        row(Request,394,requestHeight); const int actionsY=394+requestHeight+9;
        place(PasteRequest,margin,actionsY,128,34); place(Inspect,margin+138,actionsY,112,34); place(Calculate,margin+260,actionsY,148,34);
        const int labelY=actionsY+48,responseY=labelY+31,responseHeight=std::max(65,height-responseY-92);
        row(209,labelY,25); row(Response,responseY,responseHeight);
        const int footerY=responseY+responseHeight+12;
        place(210,margin,footerY+1,available-172,64); place(CopyResponse,width-margin-156,footerY,156,35);
        InvalidateRect(window,nullptr,TRUE);
    }
    void StartJob(int operation) {
        if (busy) return;
        const path directory=Text(PathBox);
        busy=true; SyncButtons();
        Set(204,L"正在核对文件…");
        if (operation==Patch) Status(L"正在备份并应用补丁…");
        if (operation==Restore) Status(L"正在恢复原版…");
        try { worker=std::thread([this,directory,operation] {
            auto result=std::make_unique<JobResult>();
            try {
                if (operation==Patch) result->message=keypatch::Patch(directory);
                if (operation==Restore) result->message=keypatch::Restore(directory);
                result->state=keypatch::InstallationState(directory);
            } catch (...) { result->error=keypatch::ErrorText(); }
            if (PostMessageW(window,JobComplete,0,reinterpret_cast<LPARAM>(result.get()))) result.release();
        }); } catch (...) { busy=false; SyncButtons(); throw; }
    }
    void CompleteJob(JobResult* pointer) {
        std::unique_ptr<JobResult> result(pointer);
        if (worker.joinable()) worker.join();
        busy=false; state=result->state;
        if (!result->error.empty()) { Set(204,L"操作未完成，请处理提示后重新检查版本。"); Error(result->error); }
        else {
            const wchar_t* description=L"目录已变化，请重新检查版本。";
            switch (state) {
            case keypatch::State::Original: description=L"版本匹配 · 原版文件，可应用补丁"; break;
            case keypatch::State::Patched: description=L"版本匹配 · 已应用补丁，可生成新请求"; break;
            case keypatch::State::Missing: description=L"未找到 libcc.dll，请选择 Navicat 安装目录"; break;
            case keypatch::State::Unsupported: description=L"文件不匹配：仅支持已核对的 Premium 18.0.6 版本"; break;
            default: break;
            }
            Set(204,description); if (!result->message.empty()) Status(result->message);
        }
        SyncButtons();
    }
    void SelectDirectory() {
        IFileOpenDialog* dialog=nullptr;
        const auto created=CoCreateInstance(CLSID_FileOpenDialog,nullptr,CLSCTX_INPROC_SERVER,IID_PPV_ARGS(&dialog));
        if (FAILED(created)) keypatch::Fail("无法打开目录选择窗口。");
        struct Scope { IFileOpenDialog* p; ~Scope() { p->Release(); } } scope{dialog};
        DWORD options=0; dialog->GetOptions(&options);
        dialog->SetOptions(options|FOS_PICKFOLDERS|FOS_FORCEFILESYSTEM); dialog->SetTitle(L"选择 Navicat 安装目录");
        const auto shown=dialog->Show(window);
        if (shown==HRESULT_FROM_WIN32(ERROR_CANCELLED)) return;
        if (FAILED(shown)) keypatch::Fail("目录选择失败。");
        IShellItem* item=nullptr;
        if (FAILED(dialog->GetResult(&item))) keypatch::Fail("无法读取所选目录。");
        struct ItemScope { IShellItem* p; ~ItemScope() { p->Release(); } } itemScope{item};
        PWSTR selected=nullptr;
        if (FAILED(item->GetDisplayName(SIGDN_FILESYSPATH,&selected))) keypatch::Fail("无法读取所选目录路径。");
        std::wstring value(selected); CoTaskMemFree(selected); Set(PathBox,value); StartJob(Check);
    }
    void Copy(const std::wstring& text) {
        if (!OpenClipboard(window)) keypatch::Fail("剪贴板忙，请重试。");
        struct Scope { ~Scope() { CloseClipboard(); } } scope;
        const auto size=(text.size()+1)*sizeof(wchar_t);
        HGLOBAL block=GlobalAlloc(GMEM_MOVEABLE,size);
        if (!block) keypatch::Fail("无法分配剪贴板内存。");
        void* memory=GlobalLock(block);
        if (!memory) { GlobalFree(block); keypatch::Fail("无法写入剪贴板。"); }
        std::memcpy(memory,text.c_str(),size); GlobalUnlock(block);
        if (!EmptyClipboard() || !SetClipboardData(CF_UNICODETEXT,block)) { GlobalFree(block); keypatch::Fail("无法写入剪贴板。"); }
    }
    void Paste() {
        if (!OpenClipboard(window)) keypatch::Fail("剪贴板忙，请重试。");
        struct Scope { ~Scope() { CloseClipboard(); } } scope;
        const auto block=GetClipboardData(CF_UNICODETEXT);
        if (!block) keypatch::Fail("剪贴板中没有文本。");
        const auto data=static_cast<const wchar_t*>(GlobalLock(block));
        if (!data) keypatch::Fail("无法读取剪贴板。");
        struct Lock { HANDLE h; ~Lock() { GlobalUnlock(h); } } lock{block};
        const auto capacity=std::min<std::size_t>(GlobalSize(block)/sizeof(wchar_t),16385);
        std::size_t count=0; while (count<capacity && data[count]) ++count;
        if (count==capacity) keypatch::Fail("剪贴板文本过长或不完整。");
        Set(Request,std::wstring(data,count));
    }
    void Dispatch(int id) {
        if (busy) return;
        switch (id) {
        case Browse: SelectDirectory(); break;
        case Check: case Patch: case Restore: StartJob(id); break;
        case Generate: Set(Serial,serial::Format(serial::Generate())); Status(L"已生成当前 Premium 18 配置的序列号。"); break;
        case CopySerial: Copy(serial::Format(keypatch::Normalize(Text(Serial)))); Status(L"已复制序列号。"); break;
        case PasteRequest: Paste(); break;
        case Inspect: {
            const auto fields=keypatch::DecryptRequest(Text(Request));
            if (keypatch::Normalize(activation::Wide(keypatch::StringField(fields,"K")))!=keypatch::Normalize(Text(Serial)))
                keypatch::Fail("请求中的序列号与上方不同。");
            Status(L"请求已解密，序列号一致，设备标识完整。可以计算激活码。"); break;
        }
        case Calculate: {
            Set(Response,L""); SyncButtons();
            const auto value=keypatch::GenerateResponse(Text(Request),Text(Name),Text(Organization),Text(Serial));
            Set(Response,activation::Wide(value)); SyncButtons();
            Status(L"激活码已生成并通过公钥回验，请复制回对应的手动激活窗口。"); break;
        }
        case CopyResponse:
            if (Text(Response).empty()) keypatch::Fail("请先计算激活码。");
            Copy(Text(Response)); Status(L"已复制激活码。"); break;
        default: break;
        }
    }
};

LRESULT CALLBACK WindowProc(HWND window,UINT message,WPARAM w,LPARAM l) {
    auto app=reinterpret_cast<App*>(GetWindowLongPtrW(window,GWLP_USERDATA));
    if (message==WM_NCCREATE) {
        app=static_cast<App*>(reinterpret_cast<CREATESTRUCTW*>(l)->lpCreateParams);
        app->window=window; SetWindowLongPtrW(window,GWLP_USERDATA,reinterpret_cast<LONG_PTR>(app));
    }
    if (!app) return DefWindowProcW(window,message,w,l);
    try {
        switch (message) {
        case WM_CREATE: app->CreateControls(); return 0;
        case WM_SIZE: app->Layout(); return 0;
        case WM_GETMINMAXINFO: {
            auto info=reinterpret_cast<MINMAXINFO*>(l);
            info->ptMinTrackSize={app->Scale(850),app->Scale(760)}; return 0;
        }
        case WM_COMMAND:
            if (app->ready) {
                const int id=LOWORD(w),notification=HIWORD(w);
                if (notification==EN_CHANGE && (id==Serial || id==Name || id==Organization || id==Request)) app->ClearResponse();
                else if (notification==EN_CHANGE && id==PathBox) app->DirectoryChanged();
                else if (notification==BN_CLICKED) app->Dispatch(id);
            }
            return 0;
        case JobComplete: app->CompleteJob(reinterpret_cast<JobResult*>(l)); return 0;
        case WM_CTLCOLORSTATIC:
            SetBkMode(reinterpret_cast<HDC>(w),TRANSPARENT); SetTextColor(reinterpret_cast<HDC>(w),RGB(38,54,76));
            return reinterpret_cast<LRESULT>(app->background);
        case WM_ERASEBKGND: {
            RECT client{}; GetClientRect(window,&client); FillRect(reinterpret_cast<HDC>(w),&client,app->background); return 1;
        }
        case WM_CLOSE:
            if (app->busy) app->Status(L"文件操作进行中，请完成后再关闭窗口。"); else DestroyWindow(window);
            return 0;
        case WM_DESTROY: PostQuitMessage(0); return 0;
        default: break;
        }
    } catch (...) {
        const auto error=keypatch::ErrorText();
        if (message==WM_CREATE) { if (!app->testing) MessageBoxW(window,error.c_str(),L"启动失败",MB_OK|MB_ICONERROR); return -1; }
        app->Error(error);
    }
    return DefWindowProcW(window,message,w,l);
}
void Require(bool value,const char* message) { if (!value) throw std::runtime_error(message); }
void RunGuiChecks(App& app) {
    auto click=[&](int id) { SendMessageW(app.window,WM_COMMAND,MAKEWPARAM(id,BN_CLICKED),reinterpret_cast<LPARAM>(app.Get(id))); };
    app.Set(Serial,activation::Wide(fixtures::cases[0].serial)); app.Set(Request,activation::Wide(fixtures::cases[0].request));
    click(Inspect); click(Calculate);
    Require(app.errorCount==0,"GUI calculation failed");
    auto fields=keypatch::RecoverResponse(app.Text(Response));
    Require(keypatch::StringField(fields,"DI")==fixtures::cases[0].device,"GUI response device mismatch");
    Require(IsWindowEnabled(app.Get(CopyResponse))!=FALSE,"Copy should be enabled");
    app.Set(Name,L"Changed"); Require(app.Text(Response).empty(),"Name change retained old response");
    Require(!IsWindowEnabled(app.Get(CopyResponse)),"Copy should be disabled");
    click(Calculate); Require(keypatch::StringField(keypatch::RecoverResponse(app.Text(Response)),"N")=="Changed","Name was not used");
    app.Set(Request,app.Text(Request)+L"\n"); Require(app.Text(Response).empty(),"Request change retained old response");
    app.state=keypatch::State::Original; app.SyncButtons();
    Require(IsWindowEnabled(app.Get(Patch)) && !IsWindowEnabled(app.Get(Restore)),"Original button state");
    app.state=keypatch::State::Patched; app.SyncButtons();
    Require(!IsWindowEnabled(app.Get(Patch)) && IsWindowEnabled(app.Get(Restore)),"Patched button state");
    app.Set(PathBox,L"C:\\changed"); Require(!IsWindowEnabled(app.Get(Patch)) && !IsWindowEnabled(app.Get(Restore)),"Directory change state");
    const auto checkDirectory=DefaultDirectory();
    const auto expectedState=keypatch::InstallationState(checkDirectory);
    app.Set(PathBox,checkDirectory.wstring());
    app.StartJob(Check);
    Require(app.busy && !IsWindowEnabled(app.Get(PathBox)),"Background check did not disable directory edits");
    SendMessageW(app.window,WM_CLOSE,0,0);
    Require(IsWindow(app.window)!=FALSE,"Window closed during file operation");
    const auto deadline=GetTickCount64()+10000;
    while (app.busy && GetTickCount64()<deadline) {
        MSG pending{};
        while (PeekMessageW(&pending,nullptr,0,0,PM_REMOVE)) { TranslateMessage(&pending); DispatchMessageW(&pending); }
        if (app.busy) MsgWaitForMultipleObjects(0,nullptr,FALSE,50,QS_ALLINPUT);
    }
    Require(!app.busy && app.state==expectedState,"Background version check failed");
    for (const auto size : {SIZE{1000,870},SIZE{850,760}}) {
        SetWindowPos(app.window,nullptr,0,0,app.Scale(size.cx),app.Scale(size.cy),SWP_NOMOVE|SWP_NOZORDER|SWP_NOACTIVATE);
        app.Layout(); RECT bounds{}; GetClientRect(app.window,&bounds);
        for (const auto& control : app.controls) {
            RECT rect{}; GetWindowRect(control.second,&rect); MapWindowPoints(nullptr,app.window,reinterpret_cast<POINT*>(&rect),2);
            Require(rect.left>=0 && rect.top>=0 && rect.right<=bounds.right && rect.bottom<=bounds.bottom && rect.right>rect.left && rect.bottom>rect.top,"GUI control outside client area");
        }
    }
    // Exercise the same GetMessage/IsDialogMessage path as the interactive window.
    PostMessageW(app.window,WM_APP+2,0,0); PostQuitMessage(0);
    MSG message{}; int dispatched=0; BOOL result;
    while ((result=GetMessageW(&message,nullptr,0,0))>0) {
        if (!IsDialogMessageW(app.window,&message)) { TranslateMessage(&message); DispatchMessageW(&message); }
        ++dispatched;
    }
    Require(result==0 && dispatched>0,"Native message loop failed");
    Require(app.errorCount==0,"Unexpected GUI error");
}
int Run(HINSTANCE instance,int show,bool testing,const path& report) {
    INITCOMMONCONTROLSEX common{sizeof(common),ICC_STANDARD_CLASSES}; InitCommonControlsEx(&common);
    SetProcessDPIAware();
    const auto initialized=CoInitializeEx(nullptr,COINIT_APARTMENTTHREADED);
    if (FAILED(initialized)) keypatch::Fail("无法初始化原生目录选择组件。");
    struct ComScope { ~ComScope() { CoUninitialize(); } } comScope;
    App app; app.testing=testing;
    WNDCLASSEXW wc{sizeof(wc)}; wc.hInstance=instance; wc.lpfnWndProc=WindowProc; wc.lpszClassName=ClassName;
    wc.hCursor=LoadCursorW(nullptr,IDC_ARROW); wc.hIcon=LoadIconW(nullptr,IDI_APPLICATION); wc.hbrBackground=reinterpret_cast<HBRUSH>(COLOR_WINDOW+1);
    keypatch::WinCheck(RegisterClassExW(&wc)!=0,"无法注册窗口");
    HDC dc=GetDC(nullptr); app.dpi=GetDeviceCaps(dc,LOGPIXELSY); ReleaseDC(nullptr,dc);
    RECT work{}; SystemParametersInfoW(SPI_GETWORKAREA,0,&work,0);
    const int width=std::min(app.Scale(1000),static_cast<int>(work.right-work.left));
    const int height=std::min(app.Scale(870),static_cast<int>(work.bottom-work.top));
    HWND window=CreateWindowExW(WS_EX_CONTROLPARENT,ClassName,L"Navicat Keypatch 18.0.6 · C++",WS_OVERLAPPEDWINDOW,
        work.left+(work.right-work.left-width)/2,work.top+(work.bottom-work.top-height)/2,width,height,nullptr,nullptr,instance,&app);
    keypatch::WinCheck(window!=nullptr,"无法创建主窗口");
    int exitCode=0;
    try {
        if (testing) {
            RunGuiChecks(app);
            std::ofstream log(report,std::ios::binary);
            if (!(log << "{\"passed\":true,\"native_cpp\":true,\"native_message_loop\":true,\"async_version_check\":true,\"calculation_and_binding\":true,\"input_invalidation\":true,\"button_states\":true,\"all_controls_default_and_minimum_bounds\":true,\"installation_modified\":false}\n")) keypatch::Fail("无法写入自检报告。");
        } else {
            ShowWindow(window,show); UpdateWindow(window); app.StartJob(Check);
            MSG message{}; BOOL result;
            while ((result=GetMessageW(&message,nullptr,0,0))>0) {
                if (!IsDialogMessageW(window,&message)) { TranslateMessage(&message); DispatchMessageW(&message); }
            }
            if (result<0) exitCode=1;
        }
    } catch (...) {
        if (testing) { std::ofstream log(report,std::ios::binary); log << "FAILED: " << activation::Utf8(keypatch::ErrorText()); }
        else MessageBoxW(window,keypatch::ErrorText().c_str(),L"运行失败",MB_OK|MB_ICONERROR);
        exitCode=1;
    }
    if (IsWindow(window)) DestroyWindow(window);
    UnregisterClassW(ClassName,instance);
    return exitCode;
}
} // namespace

int WINAPI wWinMain(HINSTANCE instance,HINSTANCE,LPWSTR,int show) {
    int count=0; LPWSTR* args=CommandLineToArgvW(GetCommandLineW(),&count);
    bool testing=false; path report;
    if (args) {
        if (count==3 && wcscmp(args[1],L"--self-test")==0) { testing=true; report=args[2]; }
        else if (count!=1) { LocalFree(args); return 2; }
        LocalFree(args);
    }
    try { return Run(instance,show,testing,report); }
    catch (...) {
        if (testing) { std::ofstream log(report,std::ios::binary); log << "FAILED: " << activation::Utf8(keypatch::ErrorText()); }
        else MessageBoxW(nullptr,keypatch::ErrorText().c_str(),L"启动失败",MB_OK|MB_ICONERROR);
        return 1;
    }
}
