$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath $PSScriptRoot
& $env:ComSpec /d /c build.cmd
if ($LASTEXITCODE -ne 0) { throw 'C++ build or core tests failed.' }
$keypatchExe = Join-Path $PSScriptRoot 'dist\NavicatKeypatch18.exe'
$keypatchReport = Join-Path $PSScriptRoot 'build-native\gui-smoke-results.json'
if (Test-Path -LiteralPath $keypatchReport) { Remove-Item -LiteralPath $keypatchReport }
$keypatchProcess = Start-Process -FilePath $keypatchExe -ArgumentList @('--self-test', ('"' + $keypatchReport + '"')) -WindowStyle Hidden -PassThru -Wait
if ($keypatchProcess.ExitCode -ne 0) { throw 'Native GUI self-test failed.' }
$keypatchResult = Get-Content -LiteralPath $keypatchReport -Raw -Encoding UTF8 | ConvertFrom-Json
if (-not $keypatchResult.passed) { throw 'Native GUI report did not pass.' }
Write-Output "C++ build and tests passed: $keypatchExe"
