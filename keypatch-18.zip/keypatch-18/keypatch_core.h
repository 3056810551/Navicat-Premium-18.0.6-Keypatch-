#pragma once
#include "rsa_math.h"
#include "key_profile.h"
#include <filesystem>
#include <fstream>
#include <chrono>
#include <tlhelp32.h>

namespace keypatch {
namespace fs = std::filesystem;
using activation::Bytes;
using Fields = std::map<std::string, activation::JsonValue>;
inline constexpr wchar_t kBackup[] = L"libcc.dll.keypatch18.original.bak";
inline constexpr char kOriginalHash[] = "d34a8194da9f5a5459ab25a9323df7ec787cdddc90ad58b33bc62d0ca84a7207";
inline constexpr char kPatchedHash[] = "bfae31129cfc21d84295f667a7efe85ad96d5575211664105b969b228ef192a1";
inline constexpr std::size_t kPatchOffset = 0x27EC415;

[[noreturn]] inline void Fail(const char* message) { throw std::runtime_error(message); }
inline void WinCheck(BOOL value, const char* message) {
    if (!value) throw std::runtime_error(std::string(message) + " (Windows " + std::to_string(GetLastError()) + ")");
}
struct Handle {
    HANDLE value = INVALID_HANDLE_VALUE;
    explicit Handle(HANDLE h = INVALID_HANDLE_VALUE) : value(h) {}
    Handle(const Handle&) = delete;
    Handle& operator=(const Handle&) = delete;
    ~Handle() { if (value != INVALID_HANDLE_VALUE && value != nullptr) CloseHandle(value); }
    void Close() { if (value != INVALID_HANDLE_VALUE && value != nullptr) CloseHandle(value); value = INVALID_HANDLE_VALUE; }
};
inline std::string HexString(const unsigned char* bytes, std::size_t size) {
    constexpr char alphabet[] = "0123456789abcdef";
    std::string result;
    for (std::size_t i = 0; i < size; ++i) { result += alphabet[bytes[i] >> 4]; result += alphabet[bytes[i] & 15]; }
    return result;
}
class Sha256 {
    BCRYPT_ALG_HANDLE algorithm = nullptr;
    BCRYPT_HASH_HANDLE hash = nullptr;
public:
    Sha256() {
        serial::Check(BCryptOpenAlgorithmProvider(&algorithm, BCRYPT_SHA256_ALGORITHM, nullptr, 0), "Open SHA256");
        const auto status = BCryptCreateHash(algorithm, &hash, nullptr, 0, nullptr, 0, 0);
        if (status < 0) { BCryptCloseAlgorithmProvider(algorithm, 0); algorithm = nullptr; serial::Check(status, "Create SHA256"); }
    }
    ~Sha256() { if (hash) BCryptDestroyHash(hash); if (algorithm) BCryptCloseAlgorithmProvider(algorithm, 0); }
    Sha256(const Sha256&) = delete;
    Sha256& operator=(const Sha256&) = delete;
    void Add(const unsigned char* data, std::size_t size) {
        while (size) {
            const auto count = static_cast<ULONG>(std::min<std::size_t>(size, 1024*1024));
            serial::Check(BCryptHashData(hash, const_cast<PUCHAR>(data), count, 0), "SHA256 input");
            data += count; size -= count;
        }
    }
    std::string Finish() {
        std::array<unsigned char, 32> result{};
        serial::Check(BCryptFinishHash(hash, result.data(), static_cast<ULONG>(result.size()), 0), "Finish SHA256");
        return HexString(result.data(), result.size());
    }
};
inline std::string Digest(const Bytes& data) { Sha256 hash; hash.Add(data.data(), data.size()); return hash.Finish(); }
inline std::string Digest(const fs::path& file) {
    Handle input(CreateFileW(file.c_str(), GENERIC_READ, FILE_SHARE_READ, nullptr, OPEN_EXISTING, FILE_FLAG_SEQUENTIAL_SCAN, nullptr));
    WinCheck(input.value != INVALID_HANDLE_VALUE, "无法读取文件，请检查目录及权限");
    Sha256 hash;
    std::array<unsigned char, 65536> buffer{};
    DWORD count = 0;
    do {
        WinCheck(ReadFile(input.value, buffer.data(), static_cast<DWORD>(buffer.size()), &count, nullptr), "读取文件失败");
        hash.Add(buffer.data(), count);
    } while (count);
    return hash.Finish();
}
inline Bytes ReadBytes(const fs::path& file) {
    std::ifstream stream(file, std::ios::binary | std::ios::ate);
    if (!stream) Fail("无法读取文件。");
    const auto length = stream.tellg();
    if (length < 0 || length > 200*1024*1024) Fail("文件大小超出支持范围。");
    Bytes result(static_cast<std::size_t>(length));
    stream.seekg(0);
    if (!result.empty() && !stream.read(reinterpret_cast<char*>(result.data()), length)) Fail("文件读取不完整。");
    return result;
}
enum class State { Unknown, Missing, Unsupported, Original, Patched };
inline State InstallationState(const fs::path& directory) {
    const auto file = directory / L"libcc.dll";
    if (!fs::is_regular_file(file)) return State::Missing;
    const auto hash = Digest(file);
    if (hash == kOriginalHash) return State::Original;
    if (hash == kPatchedHash) return State::Patched;
    return State::Unsupported;
}
inline bool NavicatRunning() {
    Handle snapshot(CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0));
    WinCheck(snapshot.value != INVALID_HANDLE_VALUE, "无法检查运行中的程序");
    PROCESSENTRY32W entry{}; entry.dwSize = sizeof(entry);
    BOOL more = Process32FirstW(snapshot.value, &entry);
    while (more) {
        if (_wcsicmp(entry.szExeFile, L"navicat.exe") == 0) return true;
        more = Process32NextW(snapshot.value, &entry);
    }
    if (GetLastError() != ERROR_NO_MORE_FILES) Fail("无法完整检查运行中的程序。");
    return false;
}
inline void AtomicReplace(const fs::path& target, const Bytes& bytes, const char* expected) {
    std::array<unsigned char, 12> random{};
    serial::Check(BCryptGenRandom(nullptr, random.data(), static_cast<ULONG>(random.size()), BCRYPT_USE_SYSTEM_PREFERRED_RNG), "Generate temporary name");
    const fs::path temporary = target.parent_path() / (L".keypatch18-" + activation::Wide(HexString(random.data(), random.size())) + L".tmp");
    Handle output(CreateFileW(temporary.c_str(), GENERIC_WRITE, 0, nullptr, CREATE_NEW, FILE_ATTRIBUTE_NORMAL | FILE_FLAG_WRITE_THROUGH, nullptr));
    WinCheck(output.value != INVALID_HANDLE_VALUE, "无法创建临时文件，请检查目录写入权限");
    struct Cleanup {
        fs::path path; Handle& output;
        ~Cleanup() { output.Close(); std::error_code ignored; fs::remove(path, ignored); }
    } cleanup{temporary, output};
    std::size_t offset = 0;
    while (offset < bytes.size()) {
        DWORD written = 0;
        const auto count = static_cast<DWORD>(std::min<std::size_t>(bytes.size()-offset, 1024*1024));
        WinCheck(WriteFile(output.value, bytes.data()+offset, count, &written, nullptr), "写入临时文件失败");
        if (!written) Fail("临时文件写入不完整。");
        offset += written;
    }
    WinCheck(FlushFileBuffers(output.value), "保存临时文件失败");
    output.Close();
    if (Digest(target) != expected) Fail("操作期间文件已变化，请重新检查目录。");
    WinCheck(ReplaceFileW(target.c_str(), temporary.c_str(), nullptr, 0, nullptr, nullptr), "替换文件失败，请关闭 Navicat 并检查写入权限");
}
inline std::wstring Patch(const fs::path& directory, bool checkProcess = true) {
    const auto state = InstallationState(directory);
    if (state == State::Patched) return L"已经应用此版本补丁。";
    if (state != State::Original) Fail("文件与支持的 Premium 18.0.6 版本不匹配，未修改。");
    if (checkProcess && NavicatRunning()) Fail("请先关闭 Navicat，再应用补丁。");
    const auto target = fs::absolute(directory) / L"libcc.dll";
    const auto backup = target.parent_path() / kBackup;
    auto bytes = ReadBytes(target);
    if (Digest(bytes) != kOriginalHash || bytes.size() <= kPatchOffset || bytes[kPatchOffset] != 0x53) Fail("原文件校验失败。");
    if (!fs::exists(backup)) {
        WinCheck(CopyFileW(target.c_str(), backup.c_str(), TRUE), "无法创建原版备份");
        Handle saved(CreateFileW(backup.c_str(), GENERIC_WRITE, FILE_SHARE_READ, nullptr, OPEN_EXISTING, 0, nullptr));
        WinCheck(saved.value != INVALID_HANDLE_VALUE, "无法确认备份已保存");
        WinCheck(FlushFileBuffers(saved.value), "无法保存原版备份");
    }
    if (Digest(backup) != kOriginalHash) Fail("已有备份不匹配，已保留该备份并停止操作。");
    bytes[kPatchOffset] = 0x54;
    if (Digest(bytes) != kPatchedHash) Fail("补丁结果校验失败。");
    AtomicReplace(target, bytes, kOriginalHash);
    if (Digest(target) != kPatchedHash) Fail("替换后的文件校验失败，请使用备份恢复。");
    return L"补丁已应用，原版已备份。请重启 Navicat，再取得新的请求码。";
}
inline std::wstring Restore(const fs::path& directory, bool checkProcess = true) {
    const auto state = InstallationState(directory);
    if (state == State::Original) return L"当前已经是原版文件。";
    if (state != State::Patched) Fail("当前文件不是本工具生成的补丁版本，未修改。");
    if (checkProcess && NavicatRunning()) Fail("请先关闭 Navicat，再恢复原版。");
    const auto target = fs::absolute(directory) / L"libcc.dll";
    auto bytes = ReadBytes(target.parent_path() / kBackup);
    if (Digest(bytes) != kOriginalHash) Fail("原版备份校验失败，未修改。");
    AtomicReplace(target, bytes, kPatchedHash);
    if (Digest(target) != kOriginalHash) Fail("恢复后的文件校验失败。");
    return L"已恢复原版文件，备份继续保留。";
}
inline std::string Normalize(std::wstring_view text) {
    auto value = activation::LicenseValue(text);
    for (auto& c : value) { if (c == '8') c = 'I'; if (c == '9') c = 'O'; }
    (void)serial::Decode(value);
    return value;
}
inline const rsa_math::Montgomery& Math() {
    static const rsa_math::Montgomery math(activation::Hex(kPatchedModulus)); return math;
}
inline Bytes Private(const Bytes& value) { return Math().Pow(value, activation::Hex(kPrivateExponent)); }
inline Bytes DecodeCode(std::wstring_view text) {
    if (text.size() > 16384) Fail("输入过长，请只粘贴请求码或激活码。");
    std::string clean;
    for (wchar_t ch : text) {
        if (ch == L' ' || ch == L'\r' || ch == L'\n' || ch == L'\t' || ch == L'\v' || ch == L'\f') continue;
        if (ch > 127) Fail("输入应为 Base64 文本。");
        clean += static_cast<char>(ch);
    }
    if (clean.size() != 344) Fail("请复制完整的请求码或激活码，应为 344 个 Base64 字符。");
    const auto block = activation::Base64Decode(clean);
    if (block.size() != 256 || activation::Base64Encode(block) != clean) Fail("Base64 编码不完整或不规范。");
    if (!rsa_math::Less(rsa_math::FromBytes(block), rsa_math::FromBytes(activation::Hex(kPatchedModulus)))) Fail("输入块与当前密钥不匹配。");
    return block;
}
inline Fields ParsePayload(const Bytes& block, unsigned char type) {
    const auto separator = std::find(block.begin()+2, block.end(), 0);
    if (block[0] != 0 || block[1] != type || separator-block.begin() < 10 || separator == block.end())
        Fail("请求或签名不匹配。请应用补丁并重启 Navicat，再取得新的请求码。");
    if (type == 1 && !std::all_of(block.begin()+2, separator, [](unsigned char b) { return b == 255; })) Fail("激活码填充不正确。");
    const std::string payload(separator+1, block.end());
    auto parsed = activation::JsonParser(payload).Parse();
    if (parsed.first.kind != activation::JsonValue::Kind::Object) Fail("请求数据必须是 JSON 对象。");
    return std::move(parsed.second);
}
inline const std::string& StringField(const Fields& fields, const char* name) {
    const auto it = fields.find(name);
    if (it == fields.end() || it->second.kind != activation::JsonValue::Kind::String) Fail("请求字段缺失或类型不正确。");
    return it->second.text;
}
inline Fields DecryptRequest(std::wstring_view text) {
    auto fields = ParsePayload(Private(DecodeCode(text)), 2);
    const auto& serialValue = StringField(fields, "K");
    const auto& device = StringField(fields, "DI");
    if (device.empty() || device.size() > 80) Fail("设备标识为空或过长。");
    if (!serial::Validate(Normalize(activation::Wide(serialValue)))) Fail("请求序列号不符合 Premium 18 配置。");
    return fields;
}
inline std::string Quote(std::string_view value) {
    (void)activation::Wide(value);
    std::string result = "\"";
    for (unsigned char c : value) {
        if (c == '"' || c == '\\') { result += '\\'; result += static_cast<char>(c); }
        else if (c == '\b') result += "\\b";
        else if (c == '\f') result += "\\f";
        else if (c == '\n') result += "\\n";
        else if (c == '\r') result += "\\r";
        else if (c == '\t') result += "\\t";
        else if (c < 0x20) result += "\\u00" + HexString(&c, 1);
        else result += static_cast<char>(c);
    }
    return result + '"';
}
inline Fields RecoverResponse(std::wstring_view text) {
    return ParsePayload(activation::PublicRecover(DecodeCode(text), kPatchedModulus), 1);
}
inline std::string GenerateResponse(std::wstring_view request, std::wstring_view name, std::wstring_view organization,
    std::wstring_view expectedSerial, std::int64_t timestamp = -1) {
    const auto fields = DecryptRequest(request);
    const auto& serialValue = StringField(fields, "K");
    if (Normalize(activation::Wide(serialValue)) != Normalize(expectedSerial)) Fail("请求码中的序列号与上方不同，请使用同一序列号生成请求。");
    if (timestamp == -1) timestamp = std::chrono::duration_cast<std::chrono::seconds>(std::chrono::system_clock::now().time_since_epoch()).count();
    const auto user = activation::Utf8(name), org = activation::Utf8(organization);
    const auto& device = StringField(fields, "DI");
    const std::string payload = "{\"K\":" + Quote(serialValue) + ",\"N\":" + Quote(user) + ",\"O\":" + Quote(org) +
        ",\"T\":" + std::to_string(timestamp) + ",\"DI\":" + Quote(device) + ",\"FA\":0}";
    if (payload.size() > 245) Fail("姓名或组织名称过长，请缩短后重试。");
    Bytes encoded(256, 255);
    encoded[0] = 0; encoded[1] = 1; encoded[255-payload.size()] = 0;
    std::copy(payload.begin(), payload.end(), encoded.end()-payload.size());
    const auto signature = Private(encoded);
    if (activation::PublicRecover(signature, kPatchedModulus) != encoded) Fail("生成结果未通过公钥回验。");
    return activation::Base64Encode(signature);
}
inline std::wstring ErrorText() {
    try { throw; }
    catch (const activation::Failure& error) { return error.detail; }
    catch (const std::exception& error) {
        try { return activation::Wide(error.what()); }
        catch (...) {
            const int count = MultiByteToWideChar(CP_ACP, 0, error.what(), -1, nullptr, 0);
            std::wstring result(count > 0 ? count : 1, L'\0');
            if (count > 0) MultiByteToWideChar(CP_ACP, 0, error.what(), -1, result.data(), count);
            if (!result.empty() && result.back() == L'\0') result.pop_back();
            return result.empty() ? L"文件操作失败，请检查路径和权限。" : result;
        }
    }
    catch (...) { return L"操作无法完成。"; }
}
} // namespace keypatch
