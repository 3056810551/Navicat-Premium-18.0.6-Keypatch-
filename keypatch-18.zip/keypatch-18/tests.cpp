#include "keypatch_core.h"
#include "test_fixtures.h"
#include <iostream>

namespace {
using namespace keypatch;
int passed=0;
void Require(bool condition,const char* message) { if (!condition) throw std::runtime_error(message); }
template<class Function> void Reject(Function function) {
    bool rejected=false;
    try { function(); } catch (const std::exception&) { rejected=true; } catch (const activation::Failure&) { rejected=true; }
    Require(rejected,"Invalid input was accepted");
}
template<class Function> void Test(const char* name,Function function) {
    function(); ++passed; std::cout << "PASS " << name << '\n';
}
std::wstring Wide(const char* text) { return activation::Wide(text); }
std::wstring EncryptedPayload(std::string_view payload,unsigned char type=2) {
    Require(payload.size()<=245,"Fixture payload too long");
    Bytes block(256,255); block[0]=0; block[1]=type;
    block[255-payload.size()]=0;
    std::copy(payload.begin(),payload.end(),block.end()-payload.size());
    return activation::Wide(activation::Base64Encode(activation::PublicRecover(block,kPatchedModulus)));
}
struct Temporary {
    fs::path root=fs::absolute(fs::temp_directory_path()), directory;
    Temporary() {
        std::array<unsigned char,12> random{};
        serial::Check(BCryptGenRandom(nullptr,random.data(),static_cast<ULONG>(random.size()),BCRYPT_USE_SYSTEM_PREFERRED_RNG),"Test temporary directory");
        directory=root/(L"keypatch18-cpp-test-"+activation::Wide(HexString(random.data(),random.size())));
        Require(fs::create_directory(directory),"Temporary directory creation failed");
    }
    ~Temporary() {
        // Delete only this exclusively created directory, directly under the temp root.
        if (directory.parent_path()==root && directory.filename().wstring().find(L"keypatch18-cpp-test-")==0) {
            std::error_code ignored; fs::remove_all(directory,ignored);
        }
    }
};
void CheckNoTemporary(const fs::path& directory) {
    for (const auto& item : fs::directory_iterator(directory))
        Require(item.path().filename().wstring().find(L".keypatch18-")!=0,"Staged temporary file leaked");
}
void CryptoTests() {
    Test("SHA256 known vectors",[] {
        Require(Digest(Bytes{})=="e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855","Empty SHA256");
        Require(Digest(Bytes{'a','b','c'})=="ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad","SHA256 abc");
    });
    Test("DES and independent serial fixtures",[] {
        const serial::Block key{0x13,0x34,0x57,0x79,0x9B,0xBC,0xDF,0xF1};
        const serial::Block plain{0x01,0x23,0x45,0x67,0x89,0xAB,0xCD,0xEF};
        const serial::Block cipher{0x85,0xE8,0x13,0x54,0x0F,0x0A,0xB4,0x05};
        Require(serial::Des(plain,key,true)==cipher && serial::Des(cipher,key,false)==plain,"DES vector");
        Require(serial::GenerateFromPrefix({0xDB,0xB7,0x82})=="NAVC25AV5XXP7A5U","Serial fixture 1");
        Require(serial::GenerateFromPrefix({0x58,0x9D,0xD8})=="NAVBHVSV4IIE2UKR","Serial fixture 2");
        for (unsigned i=0;i<100;++i) Require(serial::Validate(serial::Generate()),"Generated invalid serial");
        Require(Normalize(L"navc-25av-5xxp-7a5u")=="NAVC25AV5XXP7A5U","Serial normalization");
    });
    Test("RSA private operation against 20 independent fixtures",[] {
        for (const auto& fixture : fixtures::raw) {
            const auto input=activation::Hex(fixture.input),expected=activation::Hex(fixture.output);
            Require(Private(input)==expected,"Private modular exponentiation differs from migration fixture");
            Require(activation::PublicRecover(expected,kPatchedModulus)==input,"Independent CNG public operation mismatch");
        }
        Reject([] { Private(activation::Hex(kPatchedModulus)); });
    });
    Test("Eight request and response compatibility fixtures",[] {
        for (const auto& fixture : fixtures::cases) {
            const auto fields=DecryptRequest(Wide(fixture.request));
            Require(StringField(fields,"K")==fixture.serial,"Request K was changed");
            Require(StringField(fields,"DI")==fixture.device,"Request DI was changed");
            const auto response=GenerateResponse(Wide(fixture.request),Wide(fixture.name),Wide(fixture.organization),Wide(fixture.serial),1700000000);
            Require(response==fixture.response,"Generated response differs from independent fixture");
            const auto recovered=RecoverResponse(activation::Wide(response));
            Require(StringField(recovered,"K")==fixture.serial && StringField(recovered,"DI")==fixture.device,"Response binding mismatch");
            Require(StringField(recovered,"N")==fixture.name && StringField(recovered,"O")==fixture.organization,"Unicode or JSON escaping mismatch");
            Require(recovered.at("T").integer==1700000000,"Timestamp mismatch");
        }
    });
    Test("Mismatched serial and oversized names are rejected",[] {
        const auto request=Wide(fixtures::cases[0].request);
        Reject([&] { GenerateResponse(request,L"",L"",L"NAVBHVSV4IIE2UKR"); });
        Reject([&] { GenerateResponse(request,std::wstring(100,L'字'),L"",Wide(fixtures::cases[0].serial)); });
    });
    Test("Malformed Base64 and old-key requests are rejected",[] {
        for (const auto text : {L"",L"?",L"AAAA",L"测试"}) Reject([&] { DecryptRequest(text); });
        Reject([] { DecryptRequest(Wide(fixtures::old_request)); });
        auto code=Wide(fixtures::cases[0].request); code.pop_back(); Reject([&] { DecryptRequest(code); });
        auto fields=DecryptRequest(L" \r\n"+Wide(fixtures::cases[0].request)+L"\t");
        Require(StringField(fields,"K")==fixtures::cases[0].serial,"Whitespace request rejected");
    });
    Test("Malformed JSON, duplicate fields and invalid binding are rejected",[] {
        for (const auto payload : {"not JSON","{}","[]","{\"K\":\"x\",\"K\":\"y\",\"DI\":\"d\"}",
            "{\"K\":\"NAVC25AV5XXP7A5U\",\"DI\":\"\"}","{\"K\":\"AAAAAAAAAAAAAAAA\",\"DI\":\"d\"}",
            "{\"K\":4,\"DI\":\"d\"}","{\"K\":\"NAVC25AV5XXP7A5U\",\"DI\":true}",
            "{\"K\":\"NAVC25AV5XXP7A5U\",\"DI\":\"\\ud800\"}"}) {
            Reject([&] { DecryptRequest(EncryptedPayload(payload)); });
        }
        const auto escaped=EncryptedPayload("{\"K\":\"navc-25av-5xxp-7a5u\",\"DI\":\"device\\u0000value\",\"unknown\":[null,true,2.5]}");
        const auto response=GenerateResponse(escaped,L"",L"",L"NAVC25AV5XXP7A5U",1700000000);
        Require(StringField(RecoverResponse(activation::Wide(response)),"DI")==std::string("device\0value",12),"Embedded JSON NUL binding was changed");
    });
    Test("Wrong RSA padding and corrupted signatures are rejected",[] {
        Reject([] { DecryptRequest(EncryptedPayload("{\"K\":\"NAVC25AV5XXP7A5U\",\"DI\":\"device\"}",1)); });
        auto signature=DecodeCode(Wide(fixtures::cases[0].response)); signature[200]^=1;
        Reject([&] { RecoverResponse(activation::Wide(activation::Base64Encode(signature))); });
    });
}
void FileTests(const fs::path& source) {
    Require(Digest(source)==kOriginalHash,"Source DLL does not match pinned original");
    Test("DLL copy backup, patch, idempotence, restore and backup conflict",[&] {
        Temporary temporary; const auto target=temporary.directory/L"libcc.dll",backup=temporary.directory/kBackup;
        fs::copy_file(source,target);
        Require(InstallationState(temporary.directory)==State::Original,"Original detection");
        Patch(temporary.directory,false);
        Require(Digest(target)==kPatchedHash && Digest(backup)==kOriginalHash,"Patch or backup hash");
        Patch(temporary.directory,false); Require(Digest(backup)==kOriginalHash,"Idempotent patch changed backup");
        Restore(temporary.directory,false); Restore(temporary.directory,false);
        Require(Digest(target)==kOriginalHash && fs::exists(backup),"Restore did not preserve original and backup");
        { std::ofstream file(backup,std::ios::binary|std::ios::trunc); file << "unrelated backup"; }
        const auto backupHash=Digest(backup);
        Reject([&] { Patch(temporary.directory,false); });
        Require(Digest(target)==kOriginalHash && Digest(backup)==backupHash,"Conflicting backup was changed");
        CheckNoTemporary(temporary.directory);
    });
    Test("Locked DLL failure preserves original and cleans staged file",[&] {
        Temporary temporary; const auto target=temporary.directory/L"libcc.dll";
        fs::copy_file(source,target);
        Handle lock(CreateFileW(target.c_str(),GENERIC_READ,FILE_SHARE_READ,nullptr,OPEN_EXISTING,0,nullptr));
        WinCheck(lock.value!=INVALID_HANDLE_VALUE,"Cannot lock DLL test copy");
        Reject([&] { Patch(temporary.directory,false); });
        Require(Digest(target)==kOriginalHash,"Locked failure changed original");
        Require(Digest(temporary.directory/kBackup)==kOriginalHash,"Locked failure lost backup");
        CheckNoTemporary(temporary.directory); lock.Close();
    });
    Test("Unknown files and damaged restore backup remain untouched",[&] {
        Temporary temporary; const auto target=temporary.directory/L"libcc.dll";
        { std::ofstream file(target,std::ios::binary); file << "unsupported DLL"; }
        const auto original=Digest(target);
        Reject([&] { Patch(temporary.directory,false); }); Reject([&] { Restore(temporary.directory,false); });
        Require(Digest(target)==original && !fs::exists(temporary.directory/kBackup),"Unknown file was touched");
        fs::copy_file(source,target,fs::copy_options::overwrite_existing); Patch(temporary.directory,false);
        { std::ofstream file(temporary.directory/kBackup,std::ios::binary|std::ios::trunc); file << "damaged"; }
        Reject([&] { Restore(temporary.directory,false); });
        Require(Digest(target)==kPatchedHash,"Damaged backup changed installed copy");
        CheckNoTemporary(temporary.directory);
    });
    Require(Digest(source)==kOriginalHash,"Installed source DLL was changed by tests");
}
} // namespace
int wmain(int argc,wchar_t** argv) {
    try {
        if (argc!=2) throw std::runtime_error("Usage: KeypatchTests.exe <original-libcc.dll>");
        CryptoTests(); FileTests(argv[1]);
        std::cout << "{\"passed\":true,\"tests\":" << passed << ",\"native_cpp\":true,\"installation_modified\":false}\n";
        return 0;
    } catch (...) { std::cerr << "FAIL " << activation::Utf8(keypatch::ErrorText()) << '\n'; return 1; }
}
