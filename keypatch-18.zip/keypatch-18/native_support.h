#pragma once
#include "serial_core.h"
#include <algorithm>
#include <charconv>
#include <cstring>
#include <limits>
#include <map>
#include <optional>
#include <set>
#include <vector>

namespace activation {
using Bytes = std::vector<unsigned char>;
inline constexpr char kModulus[] =
    "c3576a1774a409a00098ccecf3cf48a9d5bd336748761de31bdc8f7262e7989886"
    "a4117813d54748c19ef283c0cb69090e674db7805c13282fb2c11f8229ef6b9b798"
    "e6df9d940280e8b142644d7190869016305e1f0660693b711e746eb6aceb2a301826"
    "49d032c4248f0512483854744206456d19d4d1fae3df87e256681888bb994809886e"
    "cf19c621cf769d680f8b54a6fb05722e1026d60d8cd9c653658f1faaef0a11a5d48"
    "44aaf132da8b89e96cbda8d48f2ae0382e8d9b299832f64d111de1b4512d2f5790"
    "6c2c937c39ad6324355ade0eb75da5c5fd3054847999c18ded70972511ce14749fd60"
    "cd759a6d14af9add67ae5eec5ba723c658eeb906b";

inline std::string Utf8(std::wstring_view text) {
    if (text.empty()) return {};
    const int count = WideCharToMultiByte(CP_UTF8, WC_ERR_INVALID_CHARS, text.data(),
        static_cast<int>(text.size()), nullptr, 0, nullptr, nullptr);
    if (!count) throw std::runtime_error("Invalid Unicode input.");
    std::string result(count, '\0');
    WideCharToMultiByte(CP_UTF8, WC_ERR_INVALID_CHARS, text.data(), static_cast<int>(text.size()),
                        result.data(), count, nullptr, nullptr);
    return result;
}

inline std::wstring Wide(std::string_view text) {
    if (text.empty()) return {};
    const int count = MultiByteToWideChar(CP_UTF8, MB_ERR_INVALID_CHARS, text.data(),
                                         static_cast<int>(text.size()), nullptr, 0);
    if (!count) throw std::runtime_error("Invalid UTF-8 data.");
    std::wstring result(count, L'\0');
    MultiByteToWideChar(CP_UTF8, MB_ERR_INVALID_CHARS, text.data(), static_cast<int>(text.size()),
                        result.data(), count);
    return result;
}

inline std::string LicenseValue(std::wstring_view text) {
    std::string value;
    for (wchar_t c : text) {
        if (c == L'-' || c == L' ' || c == L'\t' || c == L'\r' || c == L'\n') continue;
        if (c >= L'a' && c <= L'z') c -= L'a' - L'A';
        if (!((c >= L'A' && c <= L'Z') || (c >= L'0' && c <= L'9')))
            throw std::invalid_argument("序列号只能包含英文字母或数字，可带连字符和空白。");
        value += static_cast<char>(c);
    }
    if (value.size() != 16) throw std::invalid_argument("去掉连字符和空白后，序列号应为 16 个字符。");
    return value;
}

struct Failure {
    std::string stage, applicationError;
    std::wstring detail;
};
[[noreturn]] inline void Fail(const char* stage, const wchar_t* detail, const char* code = "") {
    throw Failure{stage, code, detail};
}

inline Bytes Hex(std::string_view text) {
    if (text.size() % 2) throw std::runtime_error("Invalid hexadecimal key length.");
    Bytes result;
    auto digit = [](char c) -> unsigned {
        if (c >= '0' && c <= '9') return c-'0';
        if (c >= 'a' && c <= 'f') return c-'a'+10;
        if (c >= 'A' && c <= 'F') return c-'A'+10;
        throw std::runtime_error("Invalid hexadecimal key.");
    };
    for (std::size_t i = 0; i < text.size(); i += 2)
        result.push_back(static_cast<unsigned char>((digit(text[i]) << 4) | digit(text[i+1])));
    return result;
}

inline std::string Base64Encode(const Bytes& bytes) {
    constexpr char alphabet[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    std::string out;
    for (std::size_t i = 0; i < bytes.size(); i += 3) {
        const unsigned a = bytes[i], b = i+1 < bytes.size() ? bytes[i+1] : 0,
                       c = i+2 < bytes.size() ? bytes[i+2] : 0;
        out += alphabet[a >> 2]; out += alphabet[((a & 3) << 4) | (b >> 4)];
        out += i+1 < bytes.size() ? alphabet[((b & 15) << 2) | (c >> 6)] : '=';
        out += i+2 < bytes.size() ? alphabet[c & 63] : '=';
    }
    return out;
}

inline Bytes Base64Decode(std::string_view text) {
    if (text.size() % 4) Fail("base64_strict", L"Base64 长度不是 4 的倍数。");
    auto digit = [](char c) -> unsigned {
        if (c >= 'A' && c <= 'Z') return c-'A';
        if (c >= 'a' && c <= 'z') return c-'a'+26;
        if (c >= '0' && c <= '9') return c-'0'+52;
        if (c == '+') return 62;
        if (c == '/') return 63;
        Fail("base64_strict", L"包含无效的 Base64 字符。");
    };
    Bytes out;
    for (std::size_t i = 0; i < text.size(); i += 4) {
        const unsigned a = digit(text[i]), b = digit(text[i+1]);
        const bool p2 = text[i+2] == '=', p3 = text[i+3] == '=';
        if ((p2 && !p3) || ((p2 || p3) && i+4 != text.size()))
            Fail("base64_strict", L"Base64 的等号填充位置不正确。");
        const unsigned c = p2 ? 0 : digit(text[i+2]), d = p3 ? 0 : digit(text[i+3]);
        if ((p2 && (b & 15)) || (p3 && !p2 && (c & 3)))
            Fail("base64_strict", L"Base64 填充位不符合规范编码。");
        out.push_back(static_cast<unsigned char>((a << 2) | (b >> 4)));
        if (!p2) out.push_back(static_cast<unsigned char>((b << 4) | (c >> 2)));
        if (!p3) out.push_back(static_cast<unsigned char>((c << 6) | d));
    }
    return out;
}

// CNG performs only the raw public RSA operation here; padding is checked below.
inline Bytes PublicRecover(const Bytes& input, std::string_view modulusHex = kModulus) {
    const auto modulus = Hex(modulusHex);
    if (modulus.size() != 256 || input.size() != 256)
        throw std::runtime_error("Expected a 2048-bit RSA key and a 256-byte block.");
    struct Handles {
        BCRYPT_ALG_HANDLE algorithm = nullptr;
        BCRYPT_KEY_HANDLE key = nullptr;
        ~Handles() {
            if (key) BCryptDestroyKey(key);
            if (algorithm) BCryptCloseAlgorithmProvider(algorithm, 0);
        }
    } handles;
    serial::Check(BCryptOpenAlgorithmProvider(&handles.algorithm, BCRYPT_RSA_ALGORITHM, nullptr, 0), "Open RSA provider");
    BCRYPT_RSAKEY_BLOB header{BCRYPT_RSAPUBLIC_MAGIC, 2048, 3, 256, 0, 0};
    Bytes blob(sizeof(header));
    std::memcpy(blob.data(), &header, sizeof(header));
    blob.insert(blob.end(), {1, 0, 1});
    blob.insert(blob.end(), modulus.begin(), modulus.end());
    serial::Check(BCryptImportKeyPair(handles.algorithm, nullptr, BCRYPT_RSAPUBLIC_BLOB, &handles.key,
        blob.data(), static_cast<ULONG>(blob.size()), 0), "Import RSA public key");
    // The Python model uses pow(S,e,n); reduce once for parity when S >= n.
    // This is sufficient for a 2048-bit modulus (n >= 2^2047) and a 256-byte S.
    auto block = input;
    if (!std::lexicographical_compare(block.begin(), block.end(), modulus.begin(), modulus.end())) {
        int borrow = 0;
        for (std::size_t i = block.size(); i-- > 0;) {
            const int value = static_cast<int>(block[i]) - modulus[i] - borrow;
            block[i] = static_cast<unsigned char>(value);
            borrow = value < 0 ? 1 : 0;
        }
    }
    Bytes out(256);
    ULONG length = 0;
    serial::Check(BCryptEncrypt(handles.key, block.data(), static_cast<ULONG>(block.size()),
        nullptr, nullptr, 0, out.data(), static_cast<ULONG>(out.size()), &length, BCRYPT_PAD_NONE), "RSA public recovery");
    if (length != 256) throw std::runtime_error("Unexpected RSA result length.");
    return out;
}

struct JsonValue {
    enum class Kind { Other, Object, String, Integer } kind = Kind::Other;
    std::string text;
    std::int64_t integer = 0;
};

// Bounded JSON parser for the recovered (at most 245-byte) message. Unknown
// values are parsed and discarded; duplicate object members are rejected.
class JsonParser {
    std::string_view input;
    std::size_t pos = 0;
    std::map<std::string, JsonValue> fields;
    void White() { while (pos < input.size() && (input[pos] == ' ' || input[pos] == '\t' || input[pos] == '\r' || input[pos] == '\n')) ++pos; }
    bool Eat(char c) { White(); if (pos < input.size() && input[pos] == c) { ++pos; return true; } return false; }
    [[noreturn]] void Bad() const { Fail("json_parse", L"恢复后的内容不是有效 JSON。", "90030001-1"); }
    static void AppendUtf8(std::string& out, unsigned code) {
        if (code < 0x80) out += static_cast<char>(code);
        else if (code < 0x800) {
            out += static_cast<char>(0xc0 | (code >> 6)); out += static_cast<char>(0x80 | (code & 63));
        } else if (code < 0x10000) {
            out += static_cast<char>(0xe0 | (code >> 12)); out += static_cast<char>(0x80 | ((code >> 6) & 63));
            out += static_cast<char>(0x80 | (code & 63));
        } else {
            out += static_cast<char>(0xf0 | (code >> 18)); out += static_cast<char>(0x80 | ((code >> 12) & 63));
            out += static_cast<char>(0x80 | ((code >> 6) & 63)); out += static_cast<char>(0x80 | (code & 63));
        }
    }
    unsigned Hex4() {
        unsigned code = 0;
        for (int i = 0; i < 4; ++i) {
            if (pos == input.size()) Bad();
            const char c = input[pos++];
            unsigned d;
            if (c >= '0' && c <= '9') d = c-'0';
            else if (c >= 'a' && c <= 'f') d = c-'a'+10;
            else if (c >= 'A' && c <= 'F') d = c-'A'+10;
            else Bad();
            code = (code << 4) | d;
        }
        return code;
    }
    std::string String() {
        if (!Eat('"')) Bad();
        std::string out;
        while (pos < input.size()) {
            const unsigned char c = static_cast<unsigned char>(input[pos++]);
            if (c == '"') return out;
            if (c < 0x20) Bad();
            if (c != '\\') { out += static_cast<char>(c); continue; }
            if (pos == input.size()) Bad();
            switch (input[pos++]) {
            case '"': out += '"'; break;
            case '\\': out += '\\'; break;
            case '/': out += '/'; break;
            case 'b': out += '\b'; break;
            case 'f': out += '\f'; break;
            case 'n': out += '\n'; break;
            case 'r': out += '\r'; break;
            case 't': out += '\t'; break;
            case 'u': {
                unsigned code = Hex4();
                if (code >= 0xd800 && code <= 0xdbff) {
                    if (pos+2 > input.size() || input.substr(pos, 2) != "\\u") Bad();
                    pos += 2;
                    const unsigned low = Hex4();
                    if (low < 0xdc00 || low > 0xdfff) Bad();
                    code = 0x10000 + ((code-0xd800) << 10) + low-0xdc00;
                } else if (code >= 0xdc00 && code <= 0xdfff) Bad();
                AppendUtf8(out, code); break;
            }
            default: Bad();
            }
        }
        Bad();
    }
    JsonValue Value(unsigned depth) {
        if (depth > 64) Bad();
        White();
        if (pos == input.size()) Bad();
        if (input[pos] == '"') return {JsonValue::Kind::String, String(), 0};
        if (Eat('{')) {
            std::set<std::string> names;
            if (!Eat('}')) {
                do {
                    auto key = String();
                    if (!names.insert(key).second) Fail("json_duplicate", L"数据包含重复的 JSON 字段。");
                    if (!Eat(':')) Bad();
                    auto value = Value(depth+1);
                    if (depth == 0) fields.emplace(std::move(key), std::move(value));
                    if (Eat('}')) return {JsonValue::Kind::Object, {}, 0};
                } while (Eat(','));
                Bad();
            }
            return {JsonValue::Kind::Object, {}, 0};
        }
        if (Eat('[')) {
            if (!Eat(']')) {
                do { Value(depth+1); if (Eat(']')) return {}; } while (Eat(','));
                Bad();
            }
            return {};
        }
        for (const std::string_view literal : {"true", "false", "null"}) {
            if (input.substr(pos, literal.size()) == literal) { pos += literal.size(); return {}; }
        }
        const auto start = pos;
        if (input[pos] == '-') ++pos;
        if (pos == input.size()) Bad();
        if (input[pos] == '0') ++pos;
        else {
            if (input[pos] < '1' || input[pos] > '9') Bad();
            while (pos < input.size() && input[pos] >= '0' && input[pos] <= '9') ++pos;
        }
        bool integer = true;
        if (pos < input.size() && input[pos] == '.') {
            integer = false; ++pos;
            const auto digits = pos;
            while (pos < input.size() && input[pos] >= '0' && input[pos] <= '9') ++pos;
            if (digits == pos) Bad();
        }
        if (pos < input.size() && (input[pos] == 'e' || input[pos] == 'E')) {
            integer = false; ++pos;
            if (pos < input.size() && (input[pos] == '+' || input[pos] == '-')) ++pos;
            const auto digits = pos;
            while (pos < input.size() && input[pos] >= '0' && input[pos] <= '9') ++pos;
            if (digits == pos) Bad();
        }
        std::int64_t number = 0;
        if (integer) {
            const auto result = std::from_chars(input.data()+start, input.data()+pos, number);
            if (result.ec == std::errc{} && result.ptr == input.data()+pos)
                return {JsonValue::Kind::Integer, {}, number};
        }
        return {};
    }
public:
    explicit JsonParser(std::string_view source) : input(source) {}
    std::pair<JsonValue, std::map<std::string, JsonValue>> Parse() {
        try { (void)Wide(input); } catch (const std::exception&) { Bad(); }
        auto root = Value(0);
        White();
        if (pos != input.size()) Bad();
        return {std::move(root), std::move(fields)};
    }
};

} // namespace activation
