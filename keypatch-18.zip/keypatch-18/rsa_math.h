#pragma once
#include "native_support.h"
#include <array>

namespace rsa_math {
// Fixed-width integers for the pinned 2048-bit key. No runtime or external DLL.
using Integer = std::array<std::uint32_t, 64>;
inline Integer FromBytes(const activation::Bytes& bytes) {
    if (bytes.size() != 256) throw std::runtime_error("Expected a 256-byte RSA integer.");
    Integer value{};
    for (std::size_t i = 0; i < bytes.size(); ++i)
        value[i / 4] |= std::uint32_t(bytes[255-i]) << ((i % 4) * 8);
    return value;
}
inline activation::Bytes ToBytes(const Integer& value) {
    activation::Bytes bytes(256);
    for (std::size_t i = 0; i < bytes.size(); ++i)
        bytes[255-i] = static_cast<unsigned char>(value[i / 4] >> ((i % 4) * 8));
    return bytes;
}
inline bool Less(const Integer& a, const Integer& b) {
    for (std::size_t i = a.size(); i-- > 0;)
        if (a[i] != b[i]) return a[i] < b[i];
    return false;
}
inline void Subtract(Integer& a, const Integer& b) {
    std::uint64_t borrow = 0;
    for (std::size_t i = 0; i < a.size(); ++i) {
        const std::uint64_t sub = std::uint64_t(b[i]) + borrow;
        const auto original = a[i];
        a[i] = static_cast<std::uint32_t>(std::uint64_t(original) - sub);
        borrow = std::uint64_t(original) < sub ? 1 : 0;
    }
}

class Montgomery {
    Integer modulus{}, rSquared{};
    std::uint32_t inverse = 0;
    void Double(Integer& x) const {
        std::uint32_t carry = 0;
        for (auto& limb : x) {
            const auto next = limb >> 31;
            limb = (limb << 1) | carry;
            carry = next;
        }
        if (carry || !Less(x, modulus)) Subtract(x, modulus);
    }
public:
    explicit Montgomery(const activation::Bytes& n) : modulus(FromBytes(n)) {
        if (!(modulus[0] & 1) || !(modulus.back() & 0x80000000))
            throw std::runtime_error("Expected an odd 2048-bit modulus.");
        std::uint32_t reciprocal = 1;
        for (unsigned i = 0; i < 5; ++i) reciprocal *= 2u - modulus[0] * reciprocal;
        inverse = 0u - reciprocal;
        rSquared[0] = 1;
        for (unsigned i = 0; i < 4096; ++i) Double(rSquared);
    }
    Integer Multiply(const Integer& a, const Integer& b) const {
        std::array<std::uint32_t, 130> t{};
        for (std::size_t i = 0; i < 64; ++i) {
            std::uint64_t carry = 0;
            for (std::size_t j = 0; j < 64; ++j) {
                const std::uint64_t sum = std::uint64_t(a[i]) * b[j] + t[i+j] + carry;
                t[i+j] = static_cast<std::uint32_t>(sum);
                carry = sum >> 32;
            }
            t[i+64] = static_cast<std::uint32_t>(carry);
        }
        for (std::size_t i = 0; i < 64; ++i) {
            const std::uint32_t multiplier = t[i] * inverse;
            std::uint64_t carry = 0;
            for (std::size_t j = 0; j < 64; ++j) {
                const std::uint64_t sum = std::uint64_t(multiplier) * modulus[j] + t[i+j] + carry;
                t[i+j] = static_cast<std::uint32_t>(sum);
                carry = sum >> 32;
            }
            std::size_t k = i+64;
            while (carry) {
                const std::uint64_t sum = std::uint64_t(t[k]) + carry;
                t[k++] = static_cast<std::uint32_t>(sum);
                carry = sum >> 32;
            }
        }
        Integer result{};
        std::copy_n(t.begin()+64, 64, result.begin());
        if (t[128] || !Less(result, modulus)) Subtract(result, modulus);
        return result;
    }
    activation::Bytes Pow(const activation::Bytes& bytes, const activation::Bytes& exponent) const {
        const auto input = FromBytes(bytes);
        if (!Less(input, modulus)) throw std::invalid_argument("输入块与当前密钥不匹配。");
        Integer one{}; one[0] = 1;
        auto result = Multiply(one, rSquared);
        const auto base = Multiply(input, rSquared);
        for (unsigned char byte : exponent) {
            for (int bit = 7; bit >= 0; --bit) {
                result = Multiply(result, result);
                if ((byte >> bit) & 1) result = Multiply(result, base);
            }
        }
        return ToBytes(Multiply(result, one));
    }
};
} // namespace rsa_math
