# Navicat Keypatch 18.0.6 · C++ 原生版

适配本机已核对的 **Navicat Premium 18.0.6.0，Windows x64**。独立程序位于 [dist/NavicatKeypatch18.exe](dist/NavicatKeypatch18.exe)。界面使用 Win32 原生控件，业务逻辑为 C++17，静态链接 C++ 运行库，只依赖 Windows 系统 DLL，EXE 可单独复制运行。

## 使用顺序

1. 关闭 Navicat，运行 `NavicatKeypatch18.exe`。
2. 确认安装目录，点击“检查版本”。显示“版本匹配 · 原版文件”后，点击“应用补丁并备份”。若提示没有写入权限，再以管理员身份运行工具。
3. 生成并复制序列号，启动 Navicat，在注册窗口使用该序列号，进入手动激活取得新的请求码。
4. 将新请求码粘贴回工具，保持上方序列号与生成请求时一致，填写姓名和组织，点击“检查请求”及“计算激活码”。
5. 复制激活码，粘贴到对应的 Navicat 手动激活窗口。

**补丁前取得的旧请求码不能使用。** 应用补丁后必须重新启动 Navicat，再生成请求码。姓名、组织、序列号或请求码变化后，工具会清除旧激活码，需要重新计算。

## 备份与恢复

应用补丁时，会先在所选安装目录创建 `libcc.dll.keypatch18.original.bak`，再替换 `libcc.dll`。已有备份若与原版校验值不同，工具会停止操作并保留该备份。

需要恢复时，关闭 Navicat，选择同一安装目录，检查版本后点击“恢复原版”。恢复过程也会校验备份，恢复后继续保留备份。恢复会撤销公钥补丁，由此生成的激活码不再匹配原版公钥。

## 适配范围

工具按 `libcc.dll` 的完整 SHA-256 匹配文件；仅版本号相同但文件内容不同，也会拒绝修改。

| 状态 | SHA-256 |
| --- | --- |
| 原版 | `d34a8194da9f5a5459ab25a9323df7ec787cdddc90ad58b33bc62d0ca84a7207` |
| 补丁版 | `bfae31129cfc21d84295f667a7efe85ad96d5575211664105b969b228ef192a1` |

补丁只改变 `libcc.dll` 文件偏移 `0x27EC415` 处一个字节：`53` → `54`。这会改变公钥构造结果，工具使用对应密钥处理请求与响应。每个生成的响应都会经过公钥回验。

工具不联网，不自动终止 Navicat，不自动填写产品激活窗口。

## 验证情况

- 11 组 C++ 核心及集成测试通过：包含 SHA-256/DES/序列号向量、20 组独立 RSA 运算对照、8 组请求及激活响应逐字节兼容性样本、中文与 JSON 转义、错误请求及旧请求拒绝。
- 真实 DLL 临时副本上的补丁、备份、恢复、重复操作、备份冲突、损坏备份与文件占用失败分支通过。临时文件在失败时清理。
- 原生 EXE 的控件、计算、输入变化清空旧结果、按钮状态、异步版本检查及消息循环测试通过，全部控件在默认和最小窗口尺寸内。结果为 `build-native/test-results.txt`、`build-native/gui-smoke-results.json`。
- EXE 导入表只包含 Windows 系统 DLL，见 `build-native/dependencies.txt`；最终文件校验值见 `build-native/release-verification.json`。
- 先前的隔离模拟器公钥构造验证记录保留为 `build-native/builder-verification.json`。
- 构建和测试没有修改安装中的 `libcc.dll`。尚未在 Navicat 中执行实际激活，也未完成界面人工目视检查；离线验证通过不等同于产品已成功激活。

## 源码构建

安装 Visual Studio 的“使用 C++ 的桌面开发”工作负载及 Windows SDK，在本目录运行：

```powershell
.\build.ps1
```

脚本自动选择 x64 MSVC，编译窗口程序与测试程序，运行核心测试和隐藏窗口自检。测试需要本目录上两级的原版 `libcc.dll`，只在临时副本上修改文件。普通运行和构建均不需要 Python。原 Python 实现、缓存及 PyInstaller 产物已删除。

也可用 Visual Studio 打开 `CMakeLists.txt`，选择 x64 平台构建。`build.cmd` 提供编译及核心测试入口；`build.ps1` 在此基础上执行窗口自检。

## 源码

- `main.cpp`：Win32 窗口、控件、剪贴板、目录选择和后台文件操作。
- `keypatch_core.h`：文件校验、事务替换、备份恢复、请求解密与响应生成。
- `rsa_math.h` / `key_profile.h`：固定 2048 位整数运算及当前版本密钥配置。
- `serial_core.h` / `native_support.h`：系统 BCrypt、序列号、Base64、UTF-8 与 JSON 处理。
- `tests.cpp` / `test_fixtures.h`：原生测试及独立模型生成并经复核的对照样本。
