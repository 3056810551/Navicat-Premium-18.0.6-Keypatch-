@echo off
setlocal
cd /d "%~dp0"
if /I "%VSCMD_ARG_TGT_ARCH%"=="x64" goto compiler_ready
set "KEYPATCH_VSWHERE=%ProgramFiles(x86)%\Microsoft Visual Studio\Installer\vswhere.exe"
if not exist "%KEYPATCH_VSWHERE%" goto missing_compiler
for /f "usebackq tokens=*" %%I in (`"%KEYPATCH_VSWHERE%" -latest -products * -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 -property installationPath`) do set "KEYPATCH_VSROOT=%%I"
if not defined KEYPATCH_VSROOT goto missing_compiler
call "%KEYPATCH_VSROOT%\Common7\Tools\VsDevCmd.bat" -no_logo -arch=x64 -host_arch=x64
if errorlevel 1 exit /b 1
:compiler_ready
if not exist build-native mkdir build-native
if not exist dist mkdir dist
cl /nologo /std:c++17 /utf-8 /EHsc /W4 /O2 /MT /DUNICODE /D_UNICODE main.cpp /Fo:build-native\main.obj /Fe:dist\NavicatKeypatch18.exe /link user32.lib gdi32.lib bcrypt.lib comctl32.lib shell32.lib ole32.lib uuid.lib /SUBSYSTEM:WINDOWS /MACHINE:X64 /DYNAMICBASE /NXCOMPAT /MANIFEST:EMBED /MANIFESTUAC:NO /MANIFESTINPUT:app.manifest
if errorlevel 1 exit /b 1
cl /nologo /std:c++17 /utf-8 /EHsc /W4 /O2 /MT /DUNICODE /D_UNICODE tests.cpp /Fo:build-native\tests.obj /Fe:build-native\KeypatchTests.exe /link bcrypt.lib /MACHINE:X64
if errorlevel 1 exit /b 1
build-native\KeypatchTests.exe "..\..\libcc.dll" > build-native\test-results.txt 2>&1
if errorlevel 1 (
    type build-native\test-results.txt
    exit /b 1
)
type build-native\test-results.txt
dumpbin /dependents dist\NavicatKeypatch18.exe > build-native\dependencies.txt
if errorlevel 1 exit /b 1
exit /b 0
:missing_compiler
echo Install Visual Studio with Desktop development with C++.
exit /b 1
