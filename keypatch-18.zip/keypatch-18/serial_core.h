#pragma once
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <windows.h>
#include <bcrypt.h>
#include <array>
#include <cstdint>
#include <stdexcept>
#include <string>
#include <string_view>

namespace serial {
using Block = std::array<unsigned char, 8>;
// Constant from the documented libcc.dll sample, RVA 0x8051568.
inline constexpr Block kKey{0xE9, 0x7F, 0xB0, 0x60, 0x77, 0x45, 0x90, 0xAE};
inline constexpr char kAlphabet[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567";

inline void Check(NTSTATUS status, const char* operation) {
    if (status < 0) {
        throw std::runtime_error(std::string(operation) + " failed (NTSTATUS " +
                                 std::to_string(static_cast<unsigned long>(status)) + ")");
    }
}

inline Block Des(const Block& input, const Block& secret, bool encrypt) {
    struct Handles {
        BCRYPT_ALG_HANDLE algorithm = nullptr;
        BCRYPT_KEY_HANDLE key = nullptr;
        ~Handles() {
            if (key) BCryptDestroyKey(key);
            if (algorithm) BCryptCloseAlgorithmProvider(algorithm, 0);
        }
    } handles;
    Check(BCryptOpenAlgorithmProvider(&handles.algorithm, BCRYPT_DES_ALGORITHM,
                                     nullptr, 0), "Open DES provider");
    Check(BCryptSetProperty(handles.algorithm, BCRYPT_CHAINING_MODE,
                           reinterpret_cast<PUCHAR>(const_cast<wchar_t*>(BCRYPT_CHAIN_MODE_ECB)),
                           sizeof(BCRYPT_CHAIN_MODE_ECB), 0), "Set ECB mode");
    auto mutableKey = secret;
    Check(BCryptGenerateSymmetricKey(handles.algorithm, &handles.key, nullptr, 0,
                                    mutableKey.data(), static_cast<ULONG>(mutableKey.size()), 0),
          "Create DES key");
    auto mutableInput = input;
    Block output{};
    ULONG length = 0;
    const auto transform = encrypt ? BCryptEncrypt : BCryptDecrypt;
    Check(transform(handles.key, mutableInput.data(), static_cast<ULONG>(mutableInput.size()),
                    nullptr, nullptr, 0, output.data(), static_cast<ULONG>(output.size()),
                    &length, 0), "Transform DES block");
    if (length != output.size()) throw std::runtime_error("Unexpected DES output length");
    return output;
}

inline std::string Encode(const std::array<unsigned char, 10>& bytes) {
    std::string text;
    std::uint32_t buffer = 0;
    unsigned bits = 0;
    for (auto byte : bytes) {
        buffer = (buffer << 8) | byte;
        bits += 8;
        while (bits >= 5) {
            bits -= 5;
            text += kAlphabet[(buffer >> bits) & 31];
        }
    }
    return text;
}

inline std::array<unsigned char, 10> Decode(std::string_view text) {
    if (text.size() != 16) throw std::invalid_argument("Expected 16 characters");
    std::array<unsigned char, 10> bytes{};
    std::uint32_t buffer = 0;
    unsigned bits = 0;
    std::size_t index = 0;
    for (char ch : text) {
        if (ch >= 'a' && ch <= 'z') ch = static_cast<char>(ch - 'a' + 'A');
        if (ch == '8') ch = 'I';
        if (ch == '9') ch = 'O';
        unsigned value;
        if (ch >= 'A' && ch <= 'Z') value = ch - 'A';
        else if (ch >= '2' && ch <= '7') value = ch - '2' + 26;
        else throw std::invalid_argument("Invalid Base32 character");
        buffer = (buffer << 5) | value;
        bits += 5;
        if (bits >= 8) {
            bits -= 8;
            bytes[index++] = static_cast<unsigned char>(buffer >> bits);
        }
    }
    return bytes;
}

// Checks the exact field configuration used by this generator.
inline bool Validate(std::string_view text) {
    const auto bytes = Decode(text);
    if (bytes[0] != 0x68 || bytes[1] != 0x2A) return false;
    Block encrypted{};
    for (std::size_t i = 0; i < encrypted.size(); ++i) encrypted[i] = bytes[i + 2];
    const auto plain = Des(encrypted, kKey, false);
    return plain[3] == 0xCE && plain[4] == 0x32 && plain[5] == 0x65 &&
           plain[6] == 0x20 && plain[7] == 0xFF;
}

inline std::string GenerateFromPrefix(const std::array<unsigned char, 3>& prefix) {
    // P=3, table A; E=false, M=1; V=18; low nibble=0; Ctype=2.
    const Block plain{prefix[0], prefix[1], prefix[2], 0xCE, 0x32, 0x65, 0x20, 0xFF};
    const auto encrypted = Des(plain, kKey, true);
    std::array<unsigned char, 10> bytes{0x68, 0x2A};
    for (std::size_t i = 0; i < encrypted.size(); ++i) bytes[i + 2] = encrypted[i];
    return Encode(bytes);
}

inline std::string Generate(std::string_view previous = {}) {
    for (unsigned attempt = 0; attempt < 16; ++attempt) {
        std::array<unsigned char, 3> prefix{};
        Check(BCryptGenRandom(nullptr, prefix.data(), static_cast<ULONG>(prefix.size()),
                             BCRYPT_USE_SYSTEM_PREFERRED_RNG), "Generate random bytes");
        auto text = GenerateFromPrefix(prefix);
        if (text == previous) continue;
        if (!Validate(text)) throw std::runtime_error("Generated serial failed local checks");
        return text;
    }
    throw std::runtime_error("Unable to generate a different serial");
}

inline std::wstring Format(std::string_view text, bool separators = true) {
    std::wstring output;
    for (std::size_t i = 0; i < text.size(); ++i) {
        if (separators && i && i % 4 == 0) output += L'-';
        output += static_cast<wchar_t>(text[i]);
    }
    return output;
}
} // namespace serial
